---
title: Titel
subtitle: Subtitle, if needed
shorttitle: Paper
name: Name
surname: Surname
semester: Semester
seminar: Titel Seminars
professor: Prof. Dr. XYZ
address: Behind-the-Moon-Str. 20, Bahamas
email: XYZ@googlemail.com
matrikel: "0190"
studiengang: Field of Study
modul: XY can delete
pruefungsnr: XY can delete
toc: "true"
date: 
university: 
institute:
---





\pagebreak 

# Bibliography


> -> Bibliography here!


\pagebreak
