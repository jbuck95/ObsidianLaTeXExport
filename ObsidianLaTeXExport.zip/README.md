# Writing Assignments in Obsidian.md

## Check this for installation: 


https://jbuck95.github.io/Uni/


